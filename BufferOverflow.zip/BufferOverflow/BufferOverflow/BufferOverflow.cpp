// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/*  Modified by Connie Knupp on 07/12/2025 for CS-405  */
#include <iomanip>
#include <iostream>
#include <string>


int main()
{
	//added variable for max length
	const int max_length = 20;

	std::cout << "Buffer Overflow Example" << std::endl;

	// Completed: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_number
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.
	//  You must notify the user if they entered too much data.

	const std::string account_number = "CharlieBrown42";

	//changed character array to string for best practice with memory management
	std::string user_input;

	//while input is empty
	while (user_input.empty()) {

		//prompt for input and check length
		std::cout << "Enter a value: ";
		std::getline(std::cin, user_input);
		//if length is too long
		if (user_input.length() > max_length) {
			//notify user and clear input and clear variable
			std::cout << "Must be " << max_length << " characters or less. Please try again." << std::endl;
			std::cin.clear(); //clear any input errors
			user_input.clear();  // clear variable
		}
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
